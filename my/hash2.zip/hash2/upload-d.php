<!DOCTYPE html>
<html>
<body>

<form action="fileupload-d.php" method="post" enctype="multipart/form-data">

  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>