<!DOCTYPE html>
<html>
<body>

<form action="fileupload.php" method="post" enctype="multipart/form-data">
  <input type="text" placeholder="hint" name="Hint" id="">
  <input type="text" placeholder="message" name="Message" id="">
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>