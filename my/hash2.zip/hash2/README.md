
## Motivation

> Keep myself busy and learn new stuff

## Steganography in PHP

### How to use

The Encrypt.PHP file allows us to encrypt text in an image using Steganography.  To use it, simply edit the text inside the msg variable.

The Decrypt.PHP allows us to decrypt this text from the image. The only thing you have to change here is the filename of the image.

A simple html/js form to upload images and add text will be added later when I have some more spare time.
