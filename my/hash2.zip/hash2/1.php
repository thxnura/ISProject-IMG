<?php
$ciphertext = 'pala';
$ID = '10';
echo '{"ID":"'.$ID.'","Message":"'.$ciphertext.'"}';